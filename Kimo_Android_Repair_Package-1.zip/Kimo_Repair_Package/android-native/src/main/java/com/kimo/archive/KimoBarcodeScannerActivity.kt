package com.kimo.archive

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class KimoBarcodeScannerActivity : ComponentActivity() {
    private lateinit var previewView: PreviewView
    private val executor = Executors.newSingleThreadExecutor()
    private val delivered = AtomicBoolean(false)
    private var cameraProvider: ProcessCameraProvider? = null
    private var scanner: com.google.mlkit.vision.barcode.BarcodeScanner? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK
        window.decorView.systemUiVisibility = 0 // keep system bars visible; content stays below status bar
        val root = FrameLayout(this)
        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.PERFORMANCE
        }
        root.addView(previewView, FrameLayout.LayoutParams(-1, -1))
        val hint = TextView(this).apply {
            text = "وجّه الكاميرا نحو الرمز\nسيتم التقاطه تلقائياً عند وضوحه\n\nاضغط هنا للإلغاء"
            setTextColor(-1); textSize = 16f; gravity = Gravity.CENTER
            setPadding(24, 18, 24, 18); setBackgroundColor(0x99000000.toInt())
            setOnClickListener { finishCancelled() }
        }
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER)
        root.addView(hint, lp)
        setContentView(root)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 71)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 71) { if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera() else finishCancelled() }
    }

    private fun startCamera() {
        if (isFinishing || isDestroyed) return
        // Create the ML Kit client before binding the camera so its initialization
        // overlaps camera startup instead of delaying the first preview frame.
        if (scanner == null) scanner = BarcodeScanning.getClient(KimoBarcodeNativePlugin.scannerOptions())
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                cameraProvider = future.get()
                if (isFinishing || isDestroyed) return@addListener
                val preview = Preview.Builder()
                    .setTargetRotation(previewView.display?.rotation ?: android.view.Surface.ROTATION_0)
                    .build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setTargetRotation(previewView.display?.rotation ?: android.view.Surface.ROTATION_0)
                    .build()
                analysis.setAnalyzer(executor) { proxy ->
                    val media = proxy.image
                    if (media == null || delivered.get()) { proxy.close(); return@setAnalyzer }
                    try {
                        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
                        scanner?.process(image)
                            ?.addOnSuccessListener { codes ->
                                val code = codes.firstOrNull { !it.rawValue.isNullOrBlank() }
                                if (code != null && delivered.compareAndSet(false, true)) {
                                    runOnUiThread {
                                        setResult(Activity.RESULT_OK, intent.putExtra(EXTRA_RAW, code.rawValue).putExtra(EXTRA_FORMAT, KimoBarcodeNativePlugin.formatName(code.format)))
                                        finish()
                                    }
                                }
                            }
                            ?.addOnCompleteListener { proxy.close() }
                            ?: proxy.close()
                    } catch (_: Exception) { proxy.close() }
                }
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (_: Exception) { finishCancelled() }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun finishCancelled() { setResult(Activity.RESULT_CANCELED); finish() }
    override fun onDestroy() {
        cameraProvider?.unbindAll()
        scanner?.close()
        scanner = null
        executor.shutdown()
        super.onDestroy()
    }
    companion object { const val EXTRA_RAW = "kimo_raw_value"; const val EXTRA_FORMAT = "kimo_format" }
}
