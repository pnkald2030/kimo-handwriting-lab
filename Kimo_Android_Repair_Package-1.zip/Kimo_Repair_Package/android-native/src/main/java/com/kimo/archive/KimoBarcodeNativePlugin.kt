package com.kimo.archive

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.util.Base64
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.getcapacitor.*
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executor

@CapacitorPlugin(name = "KimoBarcodeNative")
class KimoBarcodeNativePlugin : Plugin() {
    @PluginMethod
    fun scanCamera(call: PluginCall) {
        val intent = Intent(context, KimoBarcodeScannerActivity::class.java)
        startActivityForResult(call, intent, "cameraResult")
    }

    @ActivityCallback
    private fun cameraResult(call: PluginCall?, result: androidx.activity.result.ActivityResult) {
        if (call == null) return
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val data = result.data
            val raw = data?.getStringExtra(KimoBarcodeScannerActivity.EXTRA_RAW)
            val format = data?.getStringExtra(KimoBarcodeScannerActivity.EXTRA_FORMAT)
            if (!raw.isNullOrBlank()) {
                val ret = JSObject(); ret.put("rawValue", raw); ret.put("format", format ?: "غير محدد"); call.resolve(ret)
            } else call.resolve(JSObject())
        } else call.resolve(JSObject())
    }

    /** Uses Android's own secure lock: fingerprint/strong biometric or the phone's PIN, pattern or password. */
    @PluginMethod
    fun authenticate(call: PluginCall) {
        val host = activity
        if (host !is FragmentActivity) {
            call.reject("تعذر فتح نافذة حماية Android على هذا الجهاز")
            return
        }
        val manager = BiometricManager.from(context)
        val authenticators = BiometricManager.Authenticators.BIOMETRIC_STRONG or
            BiometricManager.Authenticators.DEVICE_CREDENTIAL
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val availability = manager.canAuthenticate(authenticators)
            if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
                call.reject("فعّل قفل الشاشة أو بصمة الإصبع من إعدادات الهاتف أولاً")
                return
            }
        } else {
            val keyguard = context.getSystemService(android.content.Context.KEYGUARD_SERVICE) as android.app.KeyguardManager
            if (!keyguard.isDeviceSecure) {
                call.reject("فعّل قفل الشاشة PIN أو النقش أو كلمة المرور من إعدادات الهاتف أولاً")
                return
            }
        }
        call.setKeepAlive(true)
        val executor: Executor = ContextCompat.getMainExecutor(host)
        val prompt = BiometricPrompt(host, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                call.resolve(JSObject().put("authenticated", true))
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                call.reject(errString.toString())
            }
            override fun onAuthenticationFailed() {
                // Keep the system prompt open so the user can try again.
            }
        })
        try {
            val builder = BiometricPrompt.PromptInfo.Builder()
                .setTitle("قفل تطبيق كيمو")
                .setSubtitle(call.getString("reason") ?: "تحقق من هوية صاحب الهاتف للمتابعة")
                .setConfirmationRequired(false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setAllowedAuthenticators(authenticators)
            } else {
                @Suppress("DEPRECATION")
                builder.setDeviceCredentialAllowed(true)
            }
            prompt.authenticate(builder.build())
        } catch (e: Exception) {
            call.reject(e.message ?: "تعذر تشغيل حماية الهاتف")
        }
    }

    @PluginMethod
    fun scanImage(call: PluginCall) {
        val dataUrl = call.getString("dataUrl") ?: return call.reject("لم يتم استلام الصورة")
        try {
            val encoded = dataUrl.substringAfter(',', dataUrl)
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return call.reject("تعذر فتح الصورة")
            val scanner = BarcodeScanning.getClient(scannerOptions())
            scanner.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { codes ->
                    val code = codes.firstOrNull { !it.rawValue.isNullOrBlank() }
                    scanner.close(); bitmap.recycle()
                    if (code != null) { val ret = JSObject(); ret.put("rawValue", code.rawValue); ret.put("format", formatName(code.format)); call.resolve(ret) }
                    else call.resolve(JSObject())
                }
                .addOnFailureListener { e -> scanner.close(); bitmap.recycle(); call.reject(e.message ?: "فشلت قراءة الصورة") }
        } catch (e: Exception) { call.reject(e.message ?: "تعذرت معالجة الصورة") }
    }

    @PluginMethod fun stopCamera(call: PluginCall) { call.resolve() }
    @PluginMethod fun toggleTorch(call: PluginCall) { call.resolve(JSObject().put("supported", false)) }
    @PluginMethod fun setZoomRatio(call: PluginCall) { call.resolve() }

    companion object {
        fun scannerOptions(): BarcodeScannerOptions = BarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                Barcode.FORMAT_QR_CODE, Barcode.FORMAT_AZTEC, Barcode.FORMAT_CODE_128,
                Barcode.FORMAT_CODE_39, Barcode.FORMAT_CODE_93, Barcode.FORMAT_CODABAR,
                Barcode.FORMAT_DATA_MATRIX, Barcode.FORMAT_EAN_13, Barcode.FORMAT_EAN_8,
                Barcode.FORMAT_ITF, Barcode.FORMAT_PDF417, Barcode.FORMAT_UPC_A, Barcode.FORMAT_UPC_E
            ).build()
        fun formatName(f: Int): String = when(f) {
            Barcode.FORMAT_QR_CODE -> "qr_code"; Barcode.FORMAT_AZTEC -> "aztec"; Barcode.FORMAT_CODE_128 -> "code_128"
            Barcode.FORMAT_CODE_39 -> "code_39"; Barcode.FORMAT_CODE_93 -> "code_93"; Barcode.FORMAT_CODABAR -> "codabar"
            Barcode.FORMAT_DATA_MATRIX -> "data_matrix"; Barcode.FORMAT_EAN_13 -> "ean_13"; Barcode.FORMAT_EAN_8 -> "ean_8"
            Barcode.FORMAT_ITF -> "itf"; Barcode.FORMAT_PDF417 -> "pdf417"; Barcode.FORMAT_UPC_A -> "upc_a"; Barcode.FORMAT_UPC_E -> "upc_e"
            else -> "غير محدد"
        }
    }
}
