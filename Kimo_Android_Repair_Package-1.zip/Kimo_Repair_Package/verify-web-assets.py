from html.parser import HTMLParser
from pathlib import Path
import subprocess, tempfile, sys

class Scripts(HTMLParser):
    def __init__(self):
        super().__init__(); self.in_script=False; self.external=False; self.buf=[]; self.items=[]
    def handle_starttag(self, tag, attrs):
        if tag.lower()=='script':
            self.in_script=True; self.external=any(k.lower()=='src' for k,v in attrs); self.buf=[]
    def handle_data(self, data):
        if self.in_script and not self.external: self.buf.append(data)
    def handle_endtag(self, tag):
        if tag.lower()=='script' and self.in_script:
            if not self.external: self.items.append(''.join(self.buf))
            self.in_script=False; self.external=False; self.buf=[]

html=Path('www/index.html')
if not html.exists(): sys.exit('ERROR: www/index.html is missing')
parser=Scripts(); parser.feed(html.read_text(encoding='utf-8')); parser.close()
if not parser.items: sys.exit('ERROR: no inline JavaScript blocks found')
for i, code in enumerate(parser.items, 1):
    with tempfile.NamedTemporaryFile('w', suffix='.js', encoding='utf-8', delete=False) as f:
        f.write(code); name=f.name
    result=subprocess.run(['node','--check',name], text=True, capture_output=True)
    Path(name).unlink(missing_ok=True)
    if result.returncode:
        print(f'ERROR: JavaScript block {i} is invalid:\n{result.stderr}')
        sys.exit(1)
print(f'OK: checked {len(parser.items)} inline JavaScript blocks; all are syntactically valid.')
print(f'OK: using {html.stat().st_size} bytes from the current Kimo HTML source.')
