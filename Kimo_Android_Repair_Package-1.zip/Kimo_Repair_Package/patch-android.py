from pathlib import Path
import re, shutil
root=Path(__file__).parent
android=root/'android'
app=android/'app'
# Native plugin sources
src=root/'android-native/src/main/java/com/kimo/archive'
dst=app/'src/main/java/com/kimo/archive'
dst.mkdir(parents=True,exist_ok=True)
for f in src.glob('*.kt'): shutil.copy2(f,dst/f.name)
# Kotlin plugin + Android dependencies
build=app/'build.gradle'
s=build.read_text()
if "org.jetbrains.kotlin.android" not in s:
    s=s.replace("plugins {", "plugins {\n    id 'org.jetbrains.kotlin.android' version '2.1.0'")
if 'androidx.biometric:biometric' not in s:
    s=s.replace('dependencies {', "dependencies {\n    implementation 'androidx.biometric:biometric:1.1.0'")
if 'com.google.mlkit:barcode-scanning' not in s:
    s=s.replace('dependencies {', "dependencies {\n    implementation 'com.google.mlkit:barcode-scanning:17.3.0'\n    implementation 'androidx.camera:camera-core:1.4.2'\n    implementation 'androidx.camera:camera-camera2:1.4.2'\n    implementation 'androidx.camera:camera-lifecycle:1.4.2'\n    implementation 'androidx.camera:camera-view:1.4.2'")
if 'kotlinOptions' not in s and 'android {' in s:
    s=s.replace('android {', "android {\n    kotlinOptions { jvmTarget = '21' }", 1)
build.write_text(s)
# Camera permission and scanner activity
manifest=app/'src/main/AndroidManifest.xml'
m=manifest.read_text()
if 'android.permission.CAMERA' not in m:
    m=m.replace('<application', '<uses-permission android:name="android.permission.CAMERA" />\n    <uses-feature android:name="android.hardware.camera" android:required="false" />\n    <application',1)
if 'KimoBarcodeScannerActivity' not in m:
    m=m.replace('<application', '<application',1)
    m=m.replace('</application>', '        <activity android:name="com.kimo.archive.KimoBarcodeScannerActivity" android:exported="false" android:screenOrientation="fullSensor" />\n    </application>')
manifest.write_text(m)
# Register native Capacitor plugin and fit content within system bars.
main_candidates=list((app/'src/main/java').rglob('MainActivity.java'))
if main_candidates:
    main=main_candidates[0]
    code=main.read_text()
    if 'KimoBarcodeNativePlugin' not in code:
        code=code.replace('import com.getcapacitor.BridgeActivity;', 'import com.getcapacitor.BridgeActivity;\nimport com.kimo.archive.KimoBarcodeNativePlugin;\nimport androidx.core.view.WindowCompat;\nimport androidx.core.view.ViewCompat;\nimport androidx.core.view.WindowInsetsCompat;')
        code=code.replace('public class MainActivity extends BridgeActivity {', 'public class MainActivity extends BridgeActivity {\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);\n        registerPlugin(KimoBarcodeNativePlugin.class);\n        super.onCreate(savedInstanceState);\n        ViewCompat.setOnApplyWindowInsetsListener(getBridge().getWebView(), (view, insets) -> {\n            androidx.core.graphics.Insets bars = insets.getInsets(WindowInsetsCompat.Type.systemBars());\n            view.setPadding(bars.left, bars.top, bars.right, bars.bottom);\n            return insets;\n        });\n    }')
        main.write_text(code)
